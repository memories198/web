#!/bin/bash
while true;do
  var=1
  while [[ var -lt 800000 ]];do
    var=$(($var+1))
    done
  sleep 1
done